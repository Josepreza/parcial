<?php
session_start();

    $connect = mysqli_connect('localhost','root','','crud_tareas');

    /*if(isset($connect)){
        echo "Conexion exitosa";
    }else{
        echo "ERROR";
    }*/

?>